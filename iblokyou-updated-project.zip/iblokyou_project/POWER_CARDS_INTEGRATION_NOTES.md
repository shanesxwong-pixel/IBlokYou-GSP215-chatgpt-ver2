# iBlokYou Power Cards integration notes

This update keeps the Vite/React entry point and the existing multiplayer game structure. It adds a five-card Power Cards guide to the multiplayer app, based on the cards in `public/iblokyou.html`: Swap, Force Keep, Open Book, Boundary Wall, and Third-Party Bridge.

## Included in this update
- Updated root `index.html` metadata and title while preserving `/src/main.tsx` as the app entry point.
- Added a Power Cards button in the React app header.
- Replaced the old defensive X-5 placeholder with a link to the new deck guide.
- Added the five-card guide with descriptions drawn from the standalone HTML.
- Connected Swap and Force Keep to their existing multiplayer server actions.

## Important multiplayer limitation
The current multiplayer server only implements Swap and Force Keep. Open Book trust immunity, Boundary Wall neutral blockers/turn penalty, and Third-Party Bridge shared diagonal rules are described in the guide but are deliberately marked guide-only in the UI. The local standalone HTML implements these using a separate in-browser state model; copying those DOM handlers directly into the React multiplayer app would not synchronize effects across players. These three mechanics need corresponding authoritative server state, validation, snapshots, and board rendering before they can safely be activated online.

## GitHub update
Upload/replace the full project files, not just the root `index.html`, to see the Power Cards update. At minimum replace `index.html`, `src/App.tsx`, and `src/components/PowerCardsModal.tsx`. Keep the rest of the existing project files and deployment configuration.
