import React, { useState } from 'react';
import { ArrowRightLeft, Shield, BookOpen, BrickWall, Network, X, Check, Info } from 'lucide-react';

type CardId = 'swap' | 'force-keep' | 'open-book' | 'boundary-wall' | 'third-party-bridge';

interface PowerCardsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onActivateCard?: (cardId: CardId) => void;
  canUseSwap?: boolean;
  canUseForceKeep?: boolean;
}

const cards: Array<{
  id: CardId;
  number: string;
  name: string;
  subtitle: string;
  category: string;
  description: string;
  application: string;
  implementation: 'live' | 'guide';
}> = [
  {
    id: 'swap', number: 'CARD 1', name: 'Swap', subtitle: 'Mutual exchange / reciprocity', category: 'Negotiation',
    description: 'Propose a tile exchange to another player. The other player can accept, decline, or counter-offer. The negotiation must be resolved before the turn continues.',
    application: 'Use reciprocal negotiation to exchange a useful piece or agree a mutually beneficial trade.', implementation: 'live',
  },
  {
    id: 'force-keep', number: 'CARD 2', name: 'Force Keep', subtitle: 'Flood-fill hijack / tile capture', category: 'Assertive intervention',
    description: 'Target one opponent-occupied square to capture it as a held monomino. The opponent loses one point; the captured square can be deployed later as a held tile under the game rules.',
    application: 'Use strategically to open a route or disrupt a blocking cluster. This action is irreversible once accepted by the server.', implementation: 'live',
  },
  {
    id: 'open-book', number: 'CARD 3', name: 'Open Book', subtitle: 'Trust immunity / disclosure', category: 'Positive',
    description: 'The supplied standalone HTML describes temporary trust immunity intended to protect a player from certain aggressive interactions for two full rounds.',
    application: 'A disclosure and trust-building strategy. The original HTML contains a local-board implementation; the authoritative multiplayer server still needs this effect ported before it can be activated online.', implementation: 'guide',
  },
  {
    id: 'boundary-wall', number: 'CARD 4', name: 'Boundary Wall', subtitle: 'Neutral barricade / circumscribing penalty', category: 'Negative',
    description: 'The supplied standalone HTML describes placing a neutral grey barricade on an empty square, with a circumscribing penalty that skips a subsequent turn.',
    application: 'Represents avoidance or restrictive boundary-setting. It is shown here as part of the new deck, but is not activated in multiplayer until neutral-blocker state is implemented on the server.', implementation: 'guide',
  },
  {
    id: 'third-party-bridge', number: 'CARD 5', name: 'Third-Party Bridge', subtitle: 'Collaborative diagonal / mediation', category: 'Neutral',
    description: 'The supplied standalone HTML describes a collaborative bridge placed on an empty square to create a shared diagonal connection.',
    application: 'Represents mediation and a mutually accessible route. The local HTML rule is not yet ported to the authoritative multiplayer board, so this card is informational only for now.', implementation: 'guide',
  },
];

export const PowerCardsModal: React.FC<PowerCardsModalProps> = ({
  isOpen, onClose, onActivateCard, canUseSwap = true, canUseForceKeep = true,
}) => {
  const [activeId, setActiveId] = useState<CardId>('swap');
  if (!isOpen) return null;
  const active = cards.find((card) => card.id === activeId) || cards[0];
  const canActivate = active.implementation === 'live' && (active.id === 'swap' ? canUseSwap : canUseForceKeep);
  const Icon = active.id === 'swap' ? ArrowRightLeft : active.id === 'force-keep' ? Shield : active.id === 'open-book' ? BookOpen : active.id === 'boundary-wall' ? BrickWall : Network;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Power Cards guide">
      <div className="w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-2xl bg-white border border-slate-200 shadow-2xl text-slate-900">
        <div className="flex items-start justify-between gap-4 p-5 sm:p-6 border-b border-slate-200">
          <div>
            <div className="text-[10px] font-bold tracking-[0.2em] uppercase text-indigo-700">iBlokYou · Conflict Management Edition</div>
            <h2 className="text-xl sm:text-2xl font-black mt-1">Power Cards & Strategy Deck</h2>
            <p className="text-sm text-slate-600 mt-1">The five cards from the supplied standalone HTML, adapted to the multiplayer project.</p>
          </div>
          <button onClick={onClose} className="rounded-lg p-2 hover:bg-slate-100" aria-label="Close power cards"><X className="w-5 h-5" /></button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 p-4 sm:p-5">
          {cards.map((card) => (
            <button key={card.id} onClick={() => setActiveId(card.id)} className={`text-left rounded-xl border p-3 transition-colors ${activeId === card.id ? 'border-indigo-500 bg-indigo-50 ring-2 ring-indigo-100' : 'border-slate-200 hover:bg-slate-50'}`}>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500">{card.number}</span>
                <span className={`text-[9px] font-bold uppercase rounded-full px-2 py-1 ${card.implementation === 'live' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>{card.implementation === 'live' ? 'Live action' : 'Strategy guide'}</span>
              </div>
              <div className="font-extrabold mt-2">{card.name}</div>
              <div className="text-xs text-slate-600 mt-1">{card.subtitle}</div>
            </button>
          ))}
        </div>

        <div className="mx-4 sm:mx-5 mb-4 rounded-xl border border-slate-200 bg-slate-50 p-4 sm:p-5">
          <div className="flex items-start gap-3">
            <span className="rounded-xl bg-white border border-slate-200 p-2"><Icon className="w-5 h-5 text-indigo-700" /></span>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-bold uppercase tracking-wider text-indigo-700">{active.category}</div>
              <h3 className="text-lg font-black mt-1">{active.name}: {active.subtitle}</h3>
              <p className="text-sm leading-relaxed mt-2 text-slate-700">{active.description}</p>
              <div className="mt-3 rounded-lg bg-white border border-slate-200 p-3 text-sm text-slate-600"><strong className="text-slate-900">Application:</strong> {active.application}</div>
            </div>
          </div>
        </div>

        {active.implementation === 'guide' && (
          <div className="mx-4 sm:mx-5 mb-4 flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs leading-relaxed text-amber-900">
            <Info className="w-4 h-4 shrink-0 mt-0.5" />
            <p><strong>Multiplayer safety:</strong> this card is included in the replacement deck, but its standalone-HTML effect is not yet implemented in the authoritative server. It is intentionally not activatable here so players cannot see different board states.</p>
          </div>
        )}

        <div className="flex items-center justify-between gap-3 border-t border-slate-200 p-4 sm:p-5">
          <span className="text-xs text-slate-500">Cards only execute when supported by the shared game server.</span>
          <div className="flex gap-2">
            <button onClick={onClose} className="rounded-xl px-4 py-2 text-sm font-bold border border-slate-300 hover:bg-slate-50">Close</button>
            {active.implementation === 'live' && (
              <button disabled={!canActivate} onClick={() => { onActivateCard?.(active.id); onClose(); }} className="flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed">
                <Check className="w-4 h-4" />{canActivate ? `Activate ${active.name}` : `${active.name} unavailable`}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
